
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DBN : MonoBehaviour
{
    public float gpa = 0.0f; // student's GPA, user input
    public float acceptanceProbability = 0.0f; // probability of acceptance, calculated by Bayesian network

    // Bayesian network nodes
    private bool lowGpa = false;
   

    void Start()
    {
        
        // Randomly assign Gpa

        gpa = Random.Range(1.0f,4.0f);
        gpa = (float)(int)(gpa * 100 + 0.5f) / 100;
        //gpa = (float)((int)(gpa * 100.0f + 0.5f) / 100.0f);
        // Set up Bayesian network conditional probabilities
        lowGpa = true ? gpa < 3f : false;
        //highGpa = BayesNode(0.5f, lowGpa);
        
        bool hasInternshipGivenGpa = (lowGpa ? Random.value < 0.1f : Random.value < 0.95f);
        Debug.Log("/internship? " + hasInternshipGivenGpa);

        bool hasRecommendationGivenInt = (hasInternshipGivenGpa ? Random.value  < 0.8f : Random.value < 0.2f);

        // Calculate probability of acceptance based on student's GPA, internship, and recommendation
        acceptanceProbability = BayesNode( lowGpa, hasInternshipGivenGpa ? 0.95f : 0.3f, hasRecommendationGivenInt ? 0.95f : 0.3f);
        acceptanceProbability = (float)(int)(acceptanceProbability * 100 + 0.5f) / 100;
       
       


        // Print variables and probability of acceptance to console
        Debug.Log("GPA: " + gpa);
        Debug.Log("Has internship experience: " + hasInternshipGivenGpa);
        Debug.Log("Has letter of recommendation: " + hasRecommendationGivenInt);
        Debug.Log("Probability of acceptance: " + acceptanceProbability);
    }

    

    private float BayesNode( bool parent1, float p2, float parent2)
    {
        Debug.Log("parent: " + parent2);
        if(!parent1)
        {

            if (p2>.5f)
            {
                if (parent2>0.5f)
                {
                    return Random.Range(0.85f, 1f);
                }
                else
                {
                    return Random.Range(0.7f, 0.9f);
                }
            }
            else {
                return Random.Range(0.4f, 0.65f);
                    }
        }
        else
        {

            return Random.Range(0.0f, 0.5f);
        }
    }

}

